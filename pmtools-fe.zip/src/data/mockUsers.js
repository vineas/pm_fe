export const mockUsers = [
  { id: 1, name: "Super Admin", email: "admin@company.com", role: "super_admin" },
  { id: 2, name: "Project Manager", email: "pm@company.com", role: "admin" }
];